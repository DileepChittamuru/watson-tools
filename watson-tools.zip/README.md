 
 Watson content migration 
     
 exportworksapces:

     Exports the provided workspaces content from dev environment and saves in s3
     soruce files information will be stored in dynamodb
     sends success full email to all approvers in paramter store.
     sends request mail to weach approver to import

    curl -X POST \
    https://axtlyb4c28.execute-api.eu-west-1.amazonaws.com/Prod/exportWorkspaces \
    -H 'X-APP-ID: 028a3596' \
    -H 'X-API-KEY: 58f58eea-de89-4d81-b011-dbb5e9710211' \
    -d '{"workspaceNames": ["anna-direct-debit", "anna-master-flow"] }'
