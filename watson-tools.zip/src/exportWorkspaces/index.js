const _ = require('lodash');
const Bluebird = require('bluebird');
const uuidv4 = require('uuid/v4');
const s3 = require('../utils/s3');
const dynamodb = require('../utils/dynamodb');
const watson = require('../utils/watson');
const { sendEmailToAdmins } = require('../utils/ses');
const parameterStore = require('../utils/parameterStore');
const { logger } = require('../utils/logger');
const { getRegisteredEnvSequence } = require('../utils/environments');
const CONSTANTS = require('../utils/constants');

const {
    WATSON_API_URL,
    APPCONFIG_URL,
    MIGRATION_SES_TABLE,
    S3_BUCKET_NAME,
    WATSON_IMPORT_WORKSPACES_URL,
} = process.env;

const exportWorkspace = async (targetWorkspace) => {
    const { apiKey, workspaceName, workspaceId } = targetWorkspace;
    try {
        const expConfig = {
            workspace_id: workspaceId,
            _export: true,
        };
        const assistant = watson.getWatsonAssistant(WATSON_API_URL, apiKey);
        const getWorkspace = Bluebird.promisify(assistant.getWorkspace, { context: assistant });
        logger.info(`importing workspace data for API_URL : ${WATSON_API_URL} Workspace Name :  ${workspaceName} Workspace Id : ${workspaceId}`);
        const data = await getWorkspace(expConfig);
        const fileName = `${workspaceName.replace(/ /g, '').toLowerCase()}-${workspaceId}-${(new Date().getTime())}.json`;
        const { Key } = await s3.writeS3Async(S3_BUCKET_NAME, fileName, data);
        logger.info(`migrateWorkspace :: uploaded ${workspaceName} to  ${S3_BUCKET_NAME}:: ${Key}`);
        return {
            status: CONSTANTS.MIGRATION_STATUS.SUCCESS,
            name: workspaceName,
            fromID: workspaceId,
            s3File: Key,
        };
    } catch (error) {
        logger.error(`Error while exporting workspace :: ${error}`);
        return {
            status: CONSTANTS.MIGRATION_STATUS.FAILED,
            name: workspaceName,
            error,
        };
    }
};

const getWorkspacesDetailsForEnvironments = (parameters, workspaceNames) => {
    const envToDetailsMap = CONSTANTS.ENVIRONMENT_SEQUENCE.reduce((acc, env) => {
        const environmentConfig = parameters[env];
        // if the particular environment is not available
        if (!environmentConfig) {
            return acc;
        }
        // if environment is registered
        const { admins, configuration } = environmentConfig;
        const { workspaces } = _.find(configuration.nlp, o => o.provider === 'watson') || { workspaces: [] };
        // target workspaces
        const targetWorkspaces = _.chain(workspaces)
            .keyBy('workspaceName')
            .pick(workspaceNames).value();
        const approvers = _.keyBy(admins, () => uuidv4());
        return { ...acc, [env]: { workspaces: targetWorkspaces, approvers } };
    }, {});
    return envToDetailsMap;
};

const exportWorkspacesHandler = async (event) => {
    const { headers } = event;
    try {
        const chatbotId = headers['X-APP-ID'];
        const superKey = headers['X-API-KEY'];
        const { workspaceNames } = JSON.parse(event.body);
        let parameters = [];
        let targets = {};
        logger.info(`APPCONFIG_URL :: ${APPCONFIG_URL} chatbotId :: ${chatbotId}`);
        if (chatbotId) {
            parameters = await parameterStore.getParameters(APPCONFIG_URL, chatbotId);
        } else {
            logger.error(CONSTANTS.RESPONSE.EMPTY_CHAT_BOT_ID);
            return {
                statusCode: CONSTANTS.STATUS_CODES.UNAUTHORIZED_ERROR,
                body: CONSTANTS.RESPONSE.EMPTY_CHAT_BOT_ID,
            };
        }
        logger.info(`parameters :: ${JSON.stringify(parameters)}`);
        if (parameters.superKey !== superKey) {
            logger.error(CONSTANTS.RESPONSE.INVALID_SUPERKEY, superKey);
            return {
                statusCode: CONSTANTS.STATUS_CODES.UNAUTHORIZED_ERROR,
                body: `${CONSTANTS.RESPONSE.INVALID_SUPERKEY} ${superKey}`,
            };
        }
        if (workspaceNames.length) {
            targets = getWorkspacesDetailsForEnvironments(parameters, workspaceNames);
        } else {
            logger.error(CONSTANTS.RESPONSE.EMPTY_WORKSPACES);
            return {
                statusCode: CONSTANTS.STATUS_CODES.BAD_REQUEST,
                body: CONSTANTS.RESPONSE.EMPTY_WORKSPACES,
            };
        }
        const registeredEnvironments = getRegisteredEnvSequence(Object.keys(targets));
        const currentEnvironment = _.first(registeredEnvironments);
        const nextEnvironment = registeredEnvironments[registeredEnvironments.indexOf(currentEnvironment) + 1];
        const emailContent = {
            fromStage: currentEnvironment,
            toStage: nextEnvironment,
            botId: chatbotId,
            importWorkspaceUrl: WATSON_IMPORT_WORKSPACES_URL,
        };
        let emailTemplateType = null;
        let emailSubject = null;
        let emailStageApprovers = null;
        let item = {};
        // check workspaces are available in all target environemnts
        const invalidEnvironments = _.filter(_.keys(targets), env => _.values(targets[env].workspaces).length !== workspaceNames.length);
        if (invalidEnvironments.length) {
            logger.error(`${CONSTANTS.RESPONSE.WORKSPACES_NOT_AVAILABLE} ${invalidEnvironments.join(',')}`);
            return {
                statusCode: CONSTANTS.STATUS_CODES.SERVER_ERROR,
                body: `${CONSTANTS.RESPONSE.WORKSPACES_NOT_AVAILABLE} ${invalidEnvironments.join(',')}`,
            };
        }
        const exportWorkspacePromises = _.values(targets[currentEnvironment].workspaces).map(exportWorkspace);
        const workSpaceDetails = await Promise.all(exportWorkspacePromises);
        logger.info(`Migrate watson workspaces results :: ${JSON.stringify(workSpaceDetails)}`);
        const failedWorkspaces = _.find(workSpaceDetails, o => o.status === 'failed');
        if (failedWorkspaces) {
            // email error details
            emailSubject = CONSTANTS.EMAIL_SUBJECT.EXPORT_FAILED;
            emailTemplateType = CONSTANTS.TEMPLATE_TYPES.FAILED;
            emailStageApprovers = parameters[currentEnvironment].admins;
        } else {
            // create job in database
            item = {
                id: uuidv4(),
                stageId: uuidv4(),
                workSpaceDetails,
                targets,
                chatbotId,
                stage: nextEnvironment,
                stageStatus: CONSTANTS.JOB_STATES.IN_PROGRESS,
                created_time: (new Date().getTime()),
            };
            logger.info(`Add deatils in dynamodb ::  ${item}`);
            await dynamodb.putItem(MIGRATION_SES_TABLE, item);
            // email success details
            emailSubject = `Watson workspaces migration from ${currentEnvironment} to ${nextEnvironment}`;
            emailTemplateType = CONSTANTS.TEMPLATE_TYPES.REQUEST;
            emailStageApprovers = targets[nextEnvironment].approvers;
            emailContent.jobId = item.id;
            emailContent.jobToken = item.stageId;
        }
        emailContent.workspaces = workSpaceDetails.map(workSpace => workSpace.name);
        // sending email
        await sendEmailToAdmins(emailStageApprovers, emailSubject, emailTemplateType, emailContent);
        return {
            statusCode: failedWorkspaces ? CONSTANTS.STATUS_CODES.SERVER_ERROR : CONSTANTS.STATUS_CODES.OK,
            body: JSON.stringify(workSpaceDetails),
        };
    } catch (error) {
        logger.error(`error :: ${JSON.stringify(error)}`);
        return {
            statusCode: CONSTANTS.STATUS_CODES.SERVER_ERROR,
            body: JSON.stringify(error),
        };
    }
};

module.exports = { handler: exportWorkspacesHandler };
