const _ = require('lodash');
const rp = require('request-promise');
const AssistantV1 = require('ibm-watson/assistant/v1');
const bluebird = require('bluebird');
const { logger } = require('../utils/logger');
const { ENVIRONMENT_SEQUENCE } = require('../utils/constants');
const CONSTANTS = require('../utils/constants');

const {
    WATSON_API_URL,
    APPCONFIG_URL,
} = process.env;

const deleteWatsonLogs = async () => {
    try {
        logger.info('logged into lambda');
        const appConfig = await rp({
            url: `${APPCONFIG_URL}/paramService/getParams`,
            qs: {
                path: '/appConfigV2/bots',
            },
            json: true,
        });
        logger.info('AppConfig fetched::', appConfig);
        const allWorkspaces = _.flatMapDeep(appConfig, botConfig => (
            _.map(ENVIRONMENT_SEQUENCE, (env) => {
                const NLPs = _.get(botConfig, `${env}.configuration.nlp`, []);
                const watsonNLPs = _.filter(NLPs, cfg => cfg.provider === 'watson');
                return _.map(watsonNLPs, watsonNLP => watsonNLP.workspaces);
            })
        ));

        const uniqueWorkspaces = _.uniqBy(allWorkspaces, 'apiKey');

        logger.info(`collect all uniqueWorkspaces :: ${uniqueWorkspaces}`);
        const deleteLogs = async (workspace) => {
            const assistant = new AssistantV1({
                iam_apikey: workspace.apiKey,
                version: '2019-02-28',
                url: `${WATSON_API_URL}`,
                headers: {
                    'X-Watson-Learning-Opt-Out': true,
                },
            });
            return assistant.deleteUserData({ customer_id: 'customer_id' });
        };

        const results = await bluebird.map(uniqueWorkspaces, deleteLogs, { concurrency: 3 });
        logger.info(`collect all results after deleting workspace data :: ${results}`);
        return { status: CONSTANTS.STATUS_CODES.OK, body: JSON.stringify(results) };
    } catch (error) {
        logger.error(`error :: ${error}`);
        return { statusCode: CONSTANTS.STATUS_CODES.SERVER_ERROR, body: JSON.stringify(error) };
    }
};
module.exports = { handler: deleteWatsonLogs };
