const { parameters } = require('../mocks/parameterStore');

module.exports.getParameters = (appConfigUrl) => {
    if (appConfigUrl !== '/appConfigV2/bots/') {
        throw new Error('error occurred');
    }
    return parameters;
};
