module.exports.writeS3Async = async () => undefined;
