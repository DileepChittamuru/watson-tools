const { watsonMockData } = require('../mocks/watson');

module.exports.getWatsonAssistant = () => {
    function AssistantV1() {}
    AssistantV1.prototype.getWorkspace = (config) => {
        // invalid workspace id throws an error otherwise return mock data
        if (config.workspace_id === 'e472cb5d-4193-4e85-9126-80ea09a084fa') {
            throw new Error(`URL workspaceid parameter ${config.workspace_id} is not a valid GUID`);
        }
        return watsonMockData;
    };
    return new AssistantV1();
};
