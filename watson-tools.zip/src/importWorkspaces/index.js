const _ = require('lodash');
const Bluebird = require('bluebird');
const uuidv4 = require('uuid/v4');
const s3 = require('../utils/s3');
const dynamodb = require('../utils/dynamodb');
const watson = require('../utils/watson');
const { sendEmailToAdmins } = require('../utils/ses');
const { logger } = require('../utils/logger');
const { getRegisteredEnvSequence } = require('../utils/environments');
const CONSTANTS = require('../utils/constants');

const {
    WATSON_API_URL, MIGRATION_SES_TABLE, S3_BUCKET_NAME, WATSON_IMPORT_WORKSPACES_URL,
} = process.env;

const importWorkspace = async (targetWorkspaceData) => {
    const { s3File, target } = targetWorkspaceData;
    const {
        apiKey, workspaceId, workspaceName, approvers,
    } = target;
    try {
        let workspaceContent = await s3.readS3Async(S3_BUCKET_NAME, s3File);
        workspaceContent = { ...workspaceContent, workspace_id: workspaceId };
        const assistant = watson.getWatsonAssistant(WATSON_API_URL, apiKey);
        logger.info(`importing workspace data for API_URL: ${WATSON_API_URL} Workspace Name:  ${workspaceName} Workspace Id: ${workspaceId}`);
        const updateWorkspace = Bluebird.promisify(assistant.updateWorkspace, { context: assistant });
        await updateWorkspace(workspaceContent);
        return { status: CONSTANTS.MIGRATION_STATUS.SUCCESS, name: workspaceName, approvers };
    } catch (error) {
        logger.error(`Error while importing workspace :: ${error}`);
        return { status: CONSTANTS.MIGRATION_STATUS.FAILED, name: workspaceName, error };
    }
};

const getTargetWorkspaceDetails = (job) => {
    const { workSpaceDetails, stage, targets } = job;
    return workSpaceDetails.map((workspace) => {
        const { name, s3File } = workspace;
        const target = targets[stage].workspaces[workspace.name];
        return { name, s3File, target };
    });
};

const createNextJob = async (job, results, nextEnvironment) => {
    const item = {
        id: job.id,
        stageId: uuidv4(),
        workSpaceDetails: job.workSpaceDetails,
        targets: job.targets,
        stage: nextEnvironment,
        stageStatus: CONSTANTS.JOB_STATES.IN_PROGRESS,
        created_time: (new Date().getTime()),
        chatbotId: job.chatbotId,
    };
    await dynamodb.putItem(MIGRATION_SES_TABLE, item);
    const {
        id, stageId, chatbotId,
    } = item;
    // send email
    return sendEmailToAdmins(job.targets[nextEnvironment].approvers, `Watson workspaces migration from ${job.stage} to ${nextEnvironment}`, 'request', {
        jobId: id,
        jobToken: stageId,
        fromStage: job.stage,
        toStage: nextEnvironment,
        botId: chatbotId,
        workspaces: results.map(result => result.name),
        importWorkspaceUrl: WATSON_IMPORT_WORKSPACES_URL,
    });
};

const importWorkspacesHandler = async (event) => {
    try {
        const {
            jobId, jobToken, emailToken, action,
        } = event.queryStringParameters;
        let emailtemplateType; let emailSubject; let jobState; let responseStatusCode; let responseBody;
        if (!(action === CONSTANTS.ACTIONS.APPROVED || action === CONSTANTS.ACTIONS.REJECTED)) {
            logger.error(CONSTANTS.RESPONSE.INVALID_REQUEST);
            return {
                statusCode: CONSTANTS.STATUS_CODES.SERVER_ERROR,
                body: CONSTANTS.RESPONSE.INVALID_REQUEST,
            };
        }
        const jobDetails = await dynamodb.getItem(MIGRATION_SES_TABLE, jobId, jobToken);
        const job = jobDetails.Item;
        if (!job) {
            logger.error(CONSTANTS.RESPONSE.REQUEST_NOT_FOUND);
            return {
                statusCode: CONSTANTS.STATUS_CODES.FORBIDDEN_ERROR,
                body: CONSTANTS.RESPONSE.REQUEST_NOT_FOUND,
            };
        }
        if (job.stageStatus !== CONSTANTS.JOB_STATES.IN_PROGRESS) {
            logger.error(CONSTANTS.RESPONSE.ALREADY_PROCCESSED);
            return {
                statusCode: CONSTANTS.STATUS_CODES.OK,
                body: CONSTANTS.RESPONSE.ALREADY_PROCCESSED,
            };
        }
        // invalid approver
        const approver = job.targets[job.stage].approvers[emailToken];
        if (!approver) {
            logger.error(CONSTANTS.RESPONSE.INVALID_APPROVER);
            return {
                statusCode: CONSTANTS.STATUS_CODES.OK,
                body: CONSTANTS.RESPONSE.INVALID_APPROVER,
            };
        }
        const registeredEnvironments = getRegisteredEnvSequence(Object.keys(job.targets));
        let emailContent = {
            fromStage: registeredEnvironments[registeredEnvironments.indexOf(job.stage) - 1],
            toStage: job.stage,
            botId: job.chatbotId,
        };
        if (action === CONSTANTS.ACTIONS.APPROVED) {
            const targetWorkspaceDetails = getTargetWorkspaceDetails(job);
            const importWorkspacePromises = targetWorkspaceDetails.map(importWorkspace);
            const results = await Promise.all(importWorkspacePromises);
            logger.info(`Migrate watson workspaces results :: ${JSON.stringify(results)}`);
            const failedWorkspaces = _.find(results, o => o.status === CONSTANTS.MIGRATION_STATUS.FAILED);
            if (failedWorkspaces) {
                emailSubject = CONSTANTS.EMAIL_SUBJECT.IMPORT_FAILED;
                jobState = CONSTANTS.JOB_STATES.FAILED;
                emailtemplateType = CONSTANTS.TEMPLATE_TYPES.FAILED;
            } else {
                emailSubject = CONSTANTS.EMAIL_SUBJECT.IMPORT_SUCCESS;
                emailtemplateType = CONSTANTS.TEMPLATE_TYPES.SUCCESS;
                jobState = CONSTANTS.JOB_STATES.COMPLETED;
                if (!(_.last(registeredEnvironments) === job.stage)) {
                    const nextEnvironment = registeredEnvironments[registeredEnvironments.indexOf(job.stage) + 1];
                    await createNextJob(job, results, nextEnvironment);
                }
            }
            emailContent.workspaces = results.map(result => result.name);
            emailContent = { ...emailContent, approvedBy: (approver.split('.')[0]) };
            responseStatusCode = failedWorkspaces ? CONSTANTS.STATUS_CODES.SERVER_ERROR : CONSTANTS.STATUS_CODES.OK;
            responseBody = JSON.stringify(results);
        }
        if (action === CONSTANTS.ACTIONS.REJECTED) {
            emailSubject = CONSTANTS.EMAIL_SUBJECT.IMPORT_REJECTED;
            emailtemplateType = CONSTANTS.TEMPLATE_TYPES.REJECTED;
            jobState = CONSTANTS.JOB_STATES.REJECTED;
            emailContent.workspaces = job.workSpaceDetails.map(workspace => workspace.name);
            emailContent = { ...emailContent, rejectedBy: (approver.split('.')[0]) };
            responseStatusCode = CONSTANTS.STATUS_CODES.OK;
            responseBody = CONSTANTS.RESPONSE.REJECTED;
        }
        // sending email
        await dynamodb.updateJobStatus(MIGRATION_SES_TABLE, jobId, jobToken, jobState, approver);
        const stageApprovers = job.targets[job.stage].approvers;
        await sendEmailToAdmins(stageApprovers, emailSubject, emailtemplateType, emailContent);
        return {
            statusCode: responseStatusCode,
            body: responseBody,
        };
    } catch (error) {
        logger.error(`error :: ${error}`);
        return {
            statusCode: CONSTANTS.STATUS_CODES.SERVER_ERROR,
            body: JSON.stringify(error),
        };
    }
};

module.exports = { handler: importWorkspacesHandler };
