const _ = require('lodash');
const bluebird = require('bluebird');
const s3 = require('../utils/s3');
const parameterStore = require('../utils/parameterStore');
const watson = require('../utils/watson');
const { logger } = require('../utils/logger');
const { ENVIRONMENT_SEQUENCE } = require('../utils/constants');

const {
    WATSON_API_URL,
    APPCONFIG_URL,
    S3_BUCKET_NAME,
} = process.env;

const backupWatsonSkill = async (workspace) => {
    const {
        workspaceId, workspaceName, tenant, apiKey, env,
    } = workspace;
    try {
        const expConfig = { workspace_id: workspaceId, _export: true };
        logger.info(`Retrieving workspace data for API_URL : ${WATSON_API_URL} Workspace Name :  ${workspaceName} Workspace Id : ${workspaceId}`);
        const assistant = watson.getWatsonAssistant(WATSON_API_URL, apiKey);
        const data = await assistant.getWorkspace(expConfig);
        logger.info(`Retrieved workspace data ${JSON.stringify(data)}`);
        // upload to s3
        const folder = `backups/${tenant}/${env}/${(new Date().toISOString().substr(0, 10))}`;
        const relevantWorkspaceName = `${workspaceName.replace(/ /g, '').toLowerCase()}-${workspaceId}`;
        const fileName = `${folder}/${relevantWorkspaceName}.json`;
        logger.info(`Writing workspace data to s3 bucket :: ${fileName}`);
        await s3.writeS3Async(S3_BUCKET_NAME, fileName, data);
        logger.info(`Successfully Pushed data to s3 bucket :: ${fileName}`);
        return { status: 'success', name: workspaceName, fileName };
    } catch (error) {
        return { status: 'failed', name: workspaceName, error };
    }
};

const backupWatsonSkillsHandler = async () => {
    try {
        const appConfig = await parameterStore.getParameters(APPCONFIG_URL);
        logger.info(`AppConfig fetched:: ${JSON.stringify(appConfig)}`);
        const allWorkspaces = _.flatMapDeep(appConfig, (botConfig, botId) => {
            const { tenant } = botConfig;
            return ENVIRONMENT_SEQUENCE.map((env) => {
                const nlps = _.get(botConfig, `${env}.configuration.nlp`, []);
                const watsonNlps = _.filter(nlps, cfg => cfg.provider === 'watson');
                return watsonNlps.map(watsonNlp => (
                    watsonNlp.workspaces.map(ws => ({
                        ...ws, tenant, botId, env,
                    }
                    ))
                ));
            });
        });
        logger.info(`Collected all workspaces::  ${JSON.stringify(allWorkspaces)}`);
        const results = await bluebird.map(allWorkspaces, backupWatsonSkill, { concurrency: 5 });
        logger.info(`Results :: ${JSON.stringify(results)}`);
        return results;
    } catch (error) {
        logger.error(`Error occurred when running the backup of skills :: ${JSON.stringify(error)}`);
        return error;
    }
};

module.exports = { handler: backupWatsonSkillsHandler };
