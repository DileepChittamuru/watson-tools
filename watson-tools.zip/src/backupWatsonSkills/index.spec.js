const proxyquire = require('proxyquire');

const stubs = {
    '../utils/parameterStore': require('../stubs/parameterStore'),
    '../utils/watson': require('../stubs/watson'),
    '../utils/s3': require('../stubs/s3'),
};

describe('Back up watson skills lambda handler', () => {
    it('Backup watson skills success workspaces', async () => {
        process.env.APPCONFIG_URL = '/appConfigV2/bots/';
        const backupWatsonSkillsLambda = proxyquire('./index', stubs);
        const results = await backupWatsonSkillsLambda.handler();
        // back up skills with valid workspace id
        expect(results[0].status).toBe('success');
        expect(results[0].name).toBe('Masterflow');
        expect(results[2].status).toBe('success');
        expect(results[2].name).toBe('Juniorflow');
        expect(results[3].status).toBe('success');
        expect(results[3].name).toBe('MyIntents');
    });

    it('Backup watson skills failed workspaces', async () => {
        process.env.APPCONFIG_URL = '/appConfigV2/bots/';
        const backupWatsonSkillsLambda = proxyquire('./index', stubs);
        const results = await backupWatsonSkillsLambda.handler();
        // Failed to backup with invalid workspace id
        expect(results[1].status).toBe('failed');
        expect(results[1].name).toBe('GreyIntents');
    });

    it('Backup watson skills lambda should throw error if request not found', async () => {
        process.env.APPCONFIG_URL = null;
        const backupWatsonSkillsLambda = proxyquire('./index', stubs);
        const err = await backupWatsonSkillsLambda.handler();
        expect(err.message).toBe('error occurred');
    });
});
