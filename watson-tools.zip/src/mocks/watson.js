module.exports.watsonMockData = {
    name: 'MyIntents',
    intents: [
        {
            intent: 'test22',
            examples: [

            ],
            description: 'rr',
        },
        {
            intent: 'hello1',
            examples: [

            ],
            description: 'test intent',
        },
        {
            intent: 'ashikTestNL',
            examples: [

            ],
            description: '',
        },
    ],
    entities: [],
    language: 'en',
    metadata: {},
    dialog_nodes: [
        {
            type: 'standard',
            title: 'Anything else',
            output: {
                text: {
                    values: [
                        "I didn't understand. You can try rephrasing.",
                        "Can you reword your statement? I'm not understanding.",
                        "I didn't get your meaning.",
                    ],
                    selection_policy: 'sequential',
                },
            },
            metadata: {

            },
            conditions: 'anything_else',
            dialog_node: 'Anything else',
            previous_sibling: 'Welcome',
        },
        {
            type: 'standard',
            title: 'Welcome',
            output: {
                text: {
                    values: [
                        'Hello. How can I help you?',
                    ],
                    selection_policy: 'sequential',
                },
            },
            context: {
                orc: {
                    ctx: {

                    },
                    passTo: 'ashik-test-en',
                },
                system: {
                    initialized: true,
                    dialog_stack: [
                        {
                            dialog_node: 'Welcome',
                        },
                    ],
                    _node_output_map: {
                        Welcome: {
                            0: [
                                0,
                            ],
                        },
                    },
                    dialog_turn_counter: 1,
                    dialog_request_counter: 1,
                },
                conversation_id: '50ccb8f1-8a80-442b-ba52-1e0050a0271b',
            },
            metadata: {

            },
            conditions: 'welcome',
            dialog_node: 'Welcome',
        },
    ],
    workspace_id: '3333333-6fb0-4071-8816-4a487ae523e8',
    counterexamples: [],
    learning_opt_out: true,
    status: 'Available',
};
