module.exports.parameters = {
    '023a4567': {
        acc: {
            appKey: '11a1d111-2ce2-3333-a4a5-666eaf6666',
            configuration: {
                nlp: [
                    {
                        master: 'Juniorflow',
                        password: '1234qwert',
                        provider: 'watson',
                        username: '123456-7891-1aaa-1234-1a234b567cc8',
                        workspaces: [
                            {
                                apiKey: 'qweerrttyyuuuii123ghxhxhhx77272',
                                workspaceName: 'Juniorflow',
                                workspaceId: 'qweerrttyyuuuii123ghxhxhhx77272',
                            },
                            {
                                workspaceName: 'MyIntents',
                                apiKey: 'qweerrttyyuuuii123ghxhxhhx77272',
                                workspaceId: '24567-6fb0-4071-8816-4a487ae523e8',
                            },
                        ],
                    },
                ],
            },
        },
        active: 'true',
        appId: '028a3596',
        channel: 'botframework',
        language: 'nl',
        name: 'Anna',
        superKey: '58f58eea-de89-4d81-b011-dbb5e9710211',
        tags: [
            'abnamro',
            'mainpage',
        ],
        tenant: 'Anna',
        dev: {
            appKey: 'e0a081a6-3022-41bc-8780-9730df71595f',
            configuration: {
                nlp: [
                    {
                        master: 'Masterflow',
                        password: 'ZqFVmGG0Fxpu',
                        provider: 'watson',
                        username: '2aaa0ed8-b2f1-437f-ad96-658800f7f614',
                        workspaces: [
                            {
                                isVamRequired: 'true',
                                workspaceId: 'ceaaed71-40e2-410b-98fa-46ea2f68e6d5',
                                workspaceName: 'Masterflow',
                                apiKey: 'frfr22177719087292uhy-',
                            },
                            {
                                apiKey: 'LsTQcBZ8TRsHwGdXrt6FatbOjR-6QBcQCXTTpI0ED-XL',
                                isVamRequired: 'true',
                                workspaceId: 'e472cb5d-4193-4e85-9126-80ea09a084fa',
                                workspaceName: 'GreyIntents',
                            },
                        ],
                    },
                ],
                webhook: {
                    basicAuth: {
                        password: 'test',
                        username: 'test',
                    },
                    url: 'https://pub-dev.chatbot-d.aws.abnamro.org/anna-services/callService',
                },
            },
        },
        prod: {
            appKey: 'e0a081a6-3022-41bc-8780-9730df71595f',
            configuration: {
                nlp: [{
                    provider: 'watson2',
                    workspaces: [
                        {
                            isVamRequired: 'true',
                            workspaceName: 'Masterflow',
                            apiKey: 'frfr22177719087292uhy-',
                        },
                    ],
                }],
            },
        },
    },
};
