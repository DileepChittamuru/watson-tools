const AWS = require('aws-sdk');
const fs = require('fs');
const _ = require('lodash');
const CONSTANTS = require('./constants');

AWS.config.update({ region: 'eu-west-1' });
const SES = new AWS.SES({ apiVersion: '2010-12-01' });

const Charset = 'UTF-8';

const sendEmails = async (emails, subject, template, data) => {
    const tplHtml = fs.readFileSync(`${__dirname}/../emailTemplates/${template}.email.html`, 'utf-8');
    const tplText = fs.readFileSync(`${__dirname}/../emailTemplates/${template}.email.txt`, 'utf-8');
    const tplcss = fs.readFileSync(`${__dirname}/../emailTemplates/style.css`, 'utf-8');
    const compiledHtml = _.template(tplHtml);
    const compiledText = _.template(tplText);
    const emailText = compiledText(data);
    const emailHtml = compiledHtml({ ...data, style: tplcss });
    const params = {
        Destination: { ToAddresses: emails },
        Message: {
            Body: {
                Html: { Charset, Data: emailHtml },
                Text: { Charset, Data: emailText },
            },
            Subject: { Charset, Data: subject },
        },
        Source: CONSTANTS.SES_FROM_ADDRESS,
    };
    return SES.sendEmail(params).promise();
};

const sendEmailToAdmins = async (approvers, subject, template, data) => {
    const emailPromises = _.map(approvers, (user, emailToken) => sendEmails([user], subject, template, { ...data, user: user.split('.')[0], emailToken }));
    return Promise.all(emailPromises);
};

module.exports = { sendEmailToAdmins };
