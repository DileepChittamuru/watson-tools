const _ = require('lodash');
const { ENVIRONMENT_SEQUENCE } = require('./constants');

const getRegisteredEnvSequence = registeredEnvironments => _.intersection(ENVIRONMENT_SEQUENCE, registeredEnvironments);

module.exports = { getRegisteredEnvSequence };
