const AssistantV1 = require('ibm-watson/assistant/v1');

const getWatsonAssistant = (watsonApiUrl, apiKey) => {
    const assistant = new AssistantV1({
        iam_apikey: apiKey,
        version: '2018-07-10',
        url: watsonApiUrl,
        headers: {
            'X-Watson-Learning-Opt-Out': true,
        },
    });
    return assistant;
};

module.exports = {
    getWatsonAssistant,
};
