const AWS = require('aws-sdk');

AWS.config.update({ region: 'eu-west-1' });
const docClient = new AWS.DynamoDB.DocumentClient();

const getItem = async (table, id, stageId) => {
    const params = {
        Key: { id, stageId },
        TableName: table,
    };
    return docClient.get(params).promise();
};

const putItem = async (table, item) => {
    const params = {
        Item: item,
        TableName: table,
    };
    return docClient.put(params).promise();
};

const updateJobStatus = async (table, id, stageId, stageStatus, approver = 'none') => {
    const params = {
        TableName: table,
        Key: { id, stageId },
        UpdateExpression: 'set stageStatus = :stageStatus, approver = :approver, approvedTime = :approvedTime',
        ExpressionAttributeValues: {
            ':stageStatus': stageStatus,
            ':approver': approver,
            ':approvedTime': (new Date().getTime()),
        },
        ReturnValues: 'UPDATED_NEW',
    };
    return docClient.update(params).promise();
};

module.exports = {
    getItem,
    putItem,
    updateJobStatus,
};
