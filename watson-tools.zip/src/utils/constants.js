
const ENVIRONMENT_SEQUENCE = ['dev', 'pre-test', 'test', 'pre-acc', 'acc', 'pre-prod', 'prod'];

const JOB_STATES = {
    IN_PROGRESS: 'IN_PROGRESS',
    COMPLETED: 'COMPLETED',
    FAILED: 'FAILED',
    REJECTED: 'REJECTED',
};

const ACTIONS = {
    APPROVED: 'approve',
    REJECTED: 'reject',
};

const RESPONSE = {
    INVALID_REQUEST: 'invalid request, please send the valid input',
    REQUEST_NOT_FOUND: 'Request not found',
    ALREADY_PROCCESSED: 'ALL ready proccessed, Please create a new request to migrate again.',
    INVALID_APPROVER: 'Invalid request, approver not found.',
    REJECTED: 'Request is rejected, email sent to admins with job details.',
    WORKSPACES_NOT_AVAILABLE: 'given workspace(s) not found in these environments',
    INVALID_SUPERKEY: 'Invalid superKey',
    EMPTY_CHAT_BOT_ID: 'Request to Provide bot id',
    EMPTY_WORKSPACES: 'Request to provide workspace Names',
};

const EMAIL_SUBJECT = {
    IMPORT_SUCCESS: 'Watson workspace(s) imported succefully',
    IMPORT_FAILED: 'Watson workspace(s) import failed',
    IMPORT_REJECTED: 'Watson migration request is rejected',
    EXPORT_FAILED: 'Watson workspace(s) export failed',
};

const TEMPLATE_TYPES = {
    SUCCESS: 'success',
    FAILED: 'failed',
    REJECTED: 'rejected',
    REQUEST: 'request',
};

const MIGRATION_STATUS = {
    SUCCESS: 'success',
    FAILED: 'failed',
};

const STATUS_CODES = {
    OK: 200,
    AUTH_FAILED: 212,
    BAD_REQUEST: 400,
    SERVER_ERROR: 500,
    UNAUTHORIZED_ERROR: 401,
    FORBIDDEN_ERROR: 403,
};

const SES_FROM_ADDRESS = 'praveen.bamandlapally@nl.abnamro.com';

module.exports = {
    ENVIRONMENT_SEQUENCE,
    STATUS_CODES,
    ACTIONS,
    JOB_STATES,
    RESPONSE,
    TEMPLATE_TYPES,
    EMAIL_SUBJECT,
    MIGRATION_STATUS,
    SES_FROM_ADDRESS,
};
