const AWS = require('aws-sdk');

AWS.config.update({ region: 'eu-west-1' });
const s3 = new AWS.S3({ apiVersion: '2006-03-01' });

const readS3Async = async (bucketName, fileName) => {
    const params = {
        Bucket: bucketName,
        Key: fileName,
    };
    const content = await s3.getObject(params).promise();
    return JSON.parse(content.Body.toString('utf-8'));
};

const writeS3Async = async (bucketName, fileName, data) => {
    const params = {
        Bucket: bucketName,
        Key: fileName,
        Body: JSON.stringify(data),
    };
    return s3.upload(params).promise();
};

module.exports = {
    readS3Async,
    writeS3Async,
};
