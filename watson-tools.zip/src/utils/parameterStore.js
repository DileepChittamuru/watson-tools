const rp = require('request-promise');

const getParameters = async (appConfigUrl, chatbotId) => {
    const path = chatbotId ? `/appConfigV2/bots/${chatbotId}` : '/appConfigV2/bots';
    const options = {
        url: `${appConfigUrl}/paramService/getParams`,
        qs: { path },
        json: true,
    };
    return rp(options);
};

module.exports = {
    getParameters,
};
