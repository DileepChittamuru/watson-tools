const fs = require('fs');

exports.handler = async () => {
    const spec = fs.readFileSync(`${__dirname}/../../openapi.json`, 'utf-8');
    const html = `<html>
        <head>
            <script src="https://unpkg.com/swagger-ui-dist@3/swagger-ui-bundle.js"></script>
            <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@3/swagger-ui.css">
        </head>
        <body>
            <div id="swagger-ui"></div>
            <script>
                const ui = SwaggerUIBundle({
                    spec : ${spec},
                    dom_id: '#swagger-ui',
                    presets: [
                    SwaggerUIBundle.presets.apis,
                    SwaggerUIBundle.SwaggerUIStandalonePreset
                    ]
                })
            </script>
        </body>
    </html>`;
    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'text/html',
        },
        body: html,
    };
};
