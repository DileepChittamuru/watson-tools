const fs = require('fs');

exports.handler = async () => ({
    headers: {
        'Access-Control-Allow-Origin': 'https://confluence.aws.abnamro.org',
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(JSON.parse(fs.readFileSync(`${__dirname}/../../openapi.json`, 'utf-8'))),
});
